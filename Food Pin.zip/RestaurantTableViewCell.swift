//
//  RestaurantTableViewCell.swift
//  Food Pin 2
//
//  Created by pavel on 19.03.2020.
//  Copyright © 2020 R4S. All rights reserved.
//

import UIKit



class RestaurantTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var locationLabel: UILabel!
    @IBOutlet var typeLabel: UILabel!
    @IBOutlet var thumbnailImageView: UIImageView! {
    didSet {
    thumbnailImageView.layer.cornerRadius = thumbnailImageView.bounds.width / 2
    thumbnailImageView.clipsToBounds = true }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
